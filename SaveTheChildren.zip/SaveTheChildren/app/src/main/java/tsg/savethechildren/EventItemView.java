package tsg.savethechildren;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.GetCallback;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

/**
 * Created by terrelsimeongordon on 13/10/15.
 */
public class EventItemView extends AppCompatActivity {
    // Declare Variables
    String title;
    String name;
    String photo;
    String position;
    String userID;

    EventImageLoader imageLoader = new EventImageLoader(this);


    EditText    send_donation;
    EditText   send_name;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Get the view from 0singleitemview.xml
        setContentView(R.layout.doggie_recipes_singleitemview);
        Intent i = getIntent();
        // Get the result of title
        title = i.getStringExtra("title");
        // Get the result of name
        name = i.getStringExtra("name");
        // Get the result of photo
        photo = i.getStringExtra("photo");

        userID = i.getStringExtra("userID");

        Log.e("you won ","userID "+userID);
        Log.e("you won ","name "+name);

//        userInfoSelection();

        // Locate the TextViews in 0singleitemview.xml
        TextView user = (TextView) findViewById(R.id.event_username);



        // Locate the ImageView in 0singleitemview.xml
//        ImageView imgflag = (ImageView) findViewById(R.id.doggie_recipe_img);

        // Set results to the TextViews
        user.setText(name);
            send_donation = (EditText) findViewById(R.id.send_donation);
           send_name = (EditText) findViewById(R.id.send_name);
        // Capture position and set results to the ImageView
        // Passes photo images URL into 0ImageLoader.class
//        imageLoader.DisplayImage(photo, imgflag);
    }

    public void sendMoney(View v){

       String parseMoney = send_donation.getText().toString();
        String parseName = send_name.getText().toString();
        if(!parseMoney.contentEquals("") && !parseName.contentEquals("")) {
            ParseObject gameScore = new ParseObject("donation");
            gameScore.put("user_donation", userID);
            gameScore.put("donation_string", parseMoney);
            gameScore.put("donation_name", parseName);
            gameScore.saveInBackground();
Log.e("string is not ", "show " + parseMoney);
            Log.e("string is not2 ","show "+parseName);

            Intent i = new Intent(EventItemView.this, MainActivity.class);
            startActivity(i);
        }else{
            Toast.makeText(getApplicationContext()," error try again",Toast.LENGTH_LONG).show();
        }
    }

}
