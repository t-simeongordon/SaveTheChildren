package tsg.savethechildren;

/**
 * Created by terrelsimeongordon on 06/10/15.
 */

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.Profile;
import com.facebook.ProfileTracker;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SaveCallback;
import com.parse.SignUpCallback;

import org.json.JSONObject;

import java.util.Date;

public class FragmentCustomLoginButton extends Fragment {

    private TextView mTextDetails;
    private CallbackManager mCallbackManager;
    private AccessTokenTracker mTokenTracker;
    private ProfileTracker mProfileTracker;
    public FacebookCallback<LoginResult> mFacebookCallback = new FacebookCallback<LoginResult>() {
        @Override
        public void onSuccess(LoginResult loginResult) {
            Log.d("VIVZ", "onSuccess");
            AccessToken accessToken = loginResult.getAccessToken();
            Profile profile = Profile.getCurrentProfile();
            mTextDetails.setText(constructWelcomeMessage(profile));

            //fb graph
            Log.e("onSuccess", "--------" + loginResult.getAccessToken());
            Log.e("Token", "--------" + loginResult.getAccessToken().getToken());
            Log.e("Permision", "--------" + loginResult.getRecentlyGrantedPermissions());
            Log.e("ProfileDataNameF", "--" + profile.getFirstName());
            Log.e("ProfileDataNameL", "--" + profile.getLastName());
            Log.e("ProfileDataid", "--" + profile.getId());

            Log.e("Image URI", "--" + profile.getLinkUri());

            Log.e("OnGraph", "--------------");
            GraphRequest request = GraphRequest.newMeRequest(
                    loginResult.getAccessToken(),
                    new GraphRequest.GraphJSONObjectCallback() {
                        @Override
                        public void onCompleted(
                                JSONObject object,
                                GraphResponse response) {
                            try {

                                String[] data = new String[]{"id"};

                                StringBuffer sb = new StringBuffer("");

                                for (String token : data) {

                                    sb.append("" + object.getString(token));

                                }
                                parseFBaccount(sb);
                                Log.d("duck sause yes", sb.toString());
//                                 Application code
                                Log.e("GraphResponse", "-------------" + response.toString());
                                Log.e("GraphObject", "*******8***" + object.toString());
                            } catch (Exception e) {

                                Log.e("duck sause yes", "Error parsing JSON:" + e);

                            }

                        }
                    });
            Bundle parameters = new Bundle();
            parameters.putString("fields", "id,name,email");
            request.setParameters(parameters);
            request.executeAsync();

        }

        public void parseFBaccount(StringBuffer parseFBuser) {

            final String profileUserName = parseFBuser.toString();
            final String profilePassword = parseFBuser.toString();
//            Log.e("main fb user ","*********"+profileUserName);
            Log.e("main fb password ", "*********" + profilePassword);
            PreferenceManager.getDefaultSharedPreferences(getContext()).edit().putString("fb_id", profileUserName).commit();

            //initiates/makes value stored useable
            // place this line of code within other classes
            String fb_id = PreferenceManager.getDefaultSharedPreferences(getContext()).getString("fb_id", null);

//log user in with fb
            Log.e("main fb password 2 ", "*********" + profilePassword);
            ParseUser.logInInBackground(profileUserName, profilePassword, new LogInCallback() {
                public void done(final ParseUser user, ParseException e) {
                    if (user != null) {

                        Log.e("log in fb user ", "*********" + profileUserName);
                        Log.e("log in fb password ", "*********" + profilePassword);
                        Log.e("log in fb error ", "*********" + e);


                        Intent intent;

                        intent = new Intent(getContext(), MainActivity.class);

                        startActivity(intent);

                        // Hooray! The user is logged in.
                    } else {

                        //if user is not on parse add
                        final ParseUser signupUser = new ParseUser();
                        signupUser.setUsername(profileUserName);
                        signupUser.setPassword(profilePassword);
                        Log.e("log out fb user ", "*********" + profileUserName);
                        Log.e("log out fb password ", "*********" + profilePassword);
                        signupUser.put("login_type", "Facebook");

                        signupUser.signUpInBackground(new SignUpCallback() {
                            public void done(ParseException e) {
                                if (e == null) {

//ParseUser currentuser = ParseUser.getCurrentUser();

                                    ParseObject gameScore = new ParseObject("donation");
                                    gameScore.put("user_donation", ParseUser.getCurrentUser());
                                    gameScore.put("donation_string", "£100");
                                    gameScore.put("donation_name", "tom");

                                    gameScore.saveInBackground();

//                                    signupUser.saveInBackground();

                                    // Hooray! Let them use the app now.


//                                    Toast.makeText(getActivity().getApplicationContext(), "congrats you are now signed up",
//                                            Toast.LENGTH_SHORT).show();
//

                                    Intent intent = new Intent(getContext(), MainActivity.class);
//
                                    startActivity(intent);

                                    // Hooray! Let them use the app now.
                                } else {
                                    Toast.makeText(getActivity().getApplicationContext(), "error please try again" + e.toString(),
                                            Toast.LENGTH_LONG).show();

                                    // Sign up didn't succeed. Look at the ParseException
                                    // to figure out what went wrong
                                }
                            }
                        });


                        // Signup failed. Look at the ParseException to see what happened.
                    }
                }
            });

        }


        @Override
        public void onCancel() {
            Log.d("try onCancel ", "onCancel");
        }

        @Override
        public void onError(FacebookException e) {
            Log.d("try onError ", "onError " + e);
        }
    };


    public FragmentCustomLoginButton() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mCallbackManager = CallbackManager.Factory.create();
        setupTokenTracker();
        setupProfileTracker();

        mTokenTracker.startTracking();
        mProfileTracker.startTracking();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_custom_login_button, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        setupTextDetails(view);
        setupLoginButton(view);
    }

    @Override
    public void onResume() {
        super.onResume();
        Profile profile = Profile.getCurrentProfile();
        mTextDetails.setText(constructWelcomeMessage(profile));
    }

    @Override
    public void onStop() {
        super.onStop();
        mTokenTracker.stopTracking();
        mProfileTracker.stopTracking();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mCallbackManager.onActivityResult(requestCode, resultCode, data);
    }

    private void setupTextDetails(View view) {
        mTextDetails = (TextView) view.findViewById(R.id.text_details);
    }

    private void setupTokenTracker() {
        mTokenTracker = new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(AccessToken oldAccessToken, AccessToken currentAccessToken) {
                Log.d("currentAccessToken", "******** " + currentAccessToken);


            }
        };
    }

    private void setupProfileTracker() {
        mProfileTracker = new ProfileTracker() {
            @Override
            protected void onCurrentProfileChanged(Profile oldProfile, Profile currentProfile) {
                Log.d("currentProfile", "*******" + currentProfile);
                mTextDetails.setText(constructWelcomeMessage(currentProfile));
            }
        };
    }

    private void setupLoginButton(View view) {
        LoginButton mButtonLogin = (LoginButton) view.findViewById(R.id.fb_login_button);

        mButtonLogin.setFragment(this);
//        if (Build.VERSION.SDK_INT >= 16)
//            mButtonLogin.setBackground(null);
//        else
//            mButtonLogin.setBackgroundDrawable(null);
        mButtonLogin.setCompoundDrawables(null, null, null, null);
        mButtonLogin.setReadPermissions("user_friends");
//        mButtonLogin.setReadPermissions("publish_actions");
        mButtonLogin.registerCallback(mCallbackManager, mFacebookCallback);
    }

    private String constructWelcomeMessage(Profile profile) {
        StringBuffer stringBuffer = new StringBuffer();
        if (profile != null) {
            stringBuffer.append("Welcome " + profile.getName());
        }
        return stringBuffer.toString();
    }

}

