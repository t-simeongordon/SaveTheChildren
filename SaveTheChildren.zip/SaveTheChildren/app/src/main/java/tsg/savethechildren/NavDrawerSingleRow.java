package tsg.savethechildren;

/**
 * Created by terrelsimeongordon on 29/09/15.
 */
public class NavDrawerSingleRow {

    String title;
    int images;
    NavDrawerSingleRow(String title, int image){
        this.title=title;
        this.images=image;
    }

}
