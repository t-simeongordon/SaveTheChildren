package tsg.savethechildren;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.*;
import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by terrelsimeongordon on 05/12/15.
 */
public class DonationListAdapter extends BaseAdapter {

    final com.facebook.Profile profile = com.facebook.Profile.getCurrentProfile();
    final ParseUser currentUser = ParseUser.getCurrentUser();
    // Declare Variables
    Context context;
    LayoutInflater inflater;
    EventImageLoader imageLoader;
    private List<EventFolder> DoggieRecipesList = null;

    private ArrayList<EventFolder> arraylist;

    public DonationListAdapter(Context context,
                                List<EventFolder> worldpopulationlist) {
        this.context = context;
        this.DoggieRecipesList = worldpopulationlist;
        inflater = LayoutInflater.from(context);
        this.arraylist = new ArrayList<EventFolder>();
        this.arraylist.addAll(worldpopulationlist);
        imageLoader = new EventImageLoader(context);
    }

    public class ViewHolder {
        TextView title;
        TextView name;
        TextView userID;
        TextView description;
    }

    @Override
    public int getCount() {
        return DoggieRecipesList.size();
    }

    @Override
    public Object getItem(int position) {
        return DoggieRecipesList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View view, ViewGroup parent) {
        final ViewHolder holder;
        if (view == null) {

            holder = new ViewHolder();
            view = inflater.inflate(R.layout.donation_list_item, null);
            // Locate the TextViews in 0listview_item.xml
            holder.title = (TextView) view.findViewById(R.id.donation_title);
            holder.name = (TextView) view.findViewById(R.id.donation_submitted_by);
            holder.description = (TextView) view.findViewById(R.id.donation_description);

            holder.userID = (TextView) view.findViewById(R.id.donation_user);
            holder.userID.setVisibility(View.INVISIBLE);

            // Locate the ImageView in 0listview_item.xml
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }


        if (ParseUser.getCurrentUser() != null) {
            ParseQuery<ParseUser> query = ParseUser.getQuery();
            query.getInBackground(currentUser.getObjectId(), new GetCallback<ParseUser>() {
                public void done(ParseUser object, ParseException e) {

                    if (currentUser != null && profile == null) {
                        String username = object.getString("name");
                        holder.name.setText(username);

                    }
                }
            });
        }
        if(currentUser!=null && profile!=null){

            Log.e("get username", " username " + profile.getFirstName());
            holder.name.setText("" + profile.getFirstName());
        }


        // Set the results into TextViews
        holder.title.setText(DoggieRecipesList.get(position).getTitle());
        holder.description.setText(DoggieRecipesList.get(position).getDescription());

        holder.userID.setText(DoggieRecipesList.get(position).getUserId());

        // Set the results into ImageView
  
        // Listen for ListView Item Click
//        view.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View arg0) {
//
//                LayoutInflater layoutInflater = LayoutInflater.from(context);
//                View promptView = layoutInflater.inflate(R.layout.doggie_recipes_singleitemview, null);
//
//                final AlertDialog alertD = new AlertDialog.Builder(context).create();
//
//                TextView txtTitle= (TextView) promptView.findViewById(R.id.doggie_recipe_title);
//                final TextView txtSubmittedBy= (TextView) promptView.findViewById(R.id.doggie_recipe_submitted_by);
//               final TextView txtIngredients = (TextView) promptView.findViewById(R.id.doggie_recipe_ingredients);
//               final TextView txtInstructions = (TextView) promptView.findViewById(R.id.doggie_recipe_instructions);
//                final String[] DoggieIngredients = new String[1];
//                final String[] DoggieInstructions = new String[1];
//                ImageView imgflag = (ImageView) promptView.findViewById(R.id.doggie_recipe_img);
//
//
//                txtTitle.setText(DoggieRecipesList.get(position).getTitle());
//                imageLoader.DisplayImage(DoggieRecipesList.get(position).getPhoto(),
//                        imgflag);
//
//                final Profile profile = Profile.getCurrentProfile();
//                final ParseUser currentUser = ParseUser.getCurrentUser();
//
//                if (ParseUser.getCurrentUser() != null) {
//                    ParseQuery<ParseUser> query = ParseUser.getQuery();
//                    query.getInBackground(currentUser.getObjectId(), new GetCallback<ParseUser>() {
//                        public void done(ParseUser object, ParseException e) {
//
//                            if (currentUser != null && profile == null) {
//                                String username = object.getString("name");
//                                txtSubmittedBy.setText(username);
//
//
//                            }
//                        }
//                    });
//                }
//                if(currentUser!=null && profile!=null){
//
//                    Log.e("get username", " username " + profile.getFirstName());
//                    txtSubmittedBy.setText("" + profile.getFirstName());
//                }
//
//                ParseQuery<ParseObject> ingredientsQuery = ParseQuery.getQuery("DoggieRecipes");
//                ingredientsQuery.getInBackground(DoggieRecipesList.get(position).getUserId(), new GetCallback<ParseObject>() {
//                    @Override
//                    public void done(ParseObject object, com.parse.ParseException e) {
//                        if (e == null) {
//                            // object will be your game score
//                            DoggieIngredients[0] = object.getString("ingredients");
//                            txtIngredients.setText(DoggieIngredients[0]);
//
//                            Log.e("get DoggieIngredients ", " id >>>>>>>>>>>> " + DoggieIngredients[0]);
//                        } else {
//                            // something went wrong
//                            Log.e("something went wrong ", " ");
//                        }
//                    }
//
//                });
//
//                ParseQuery<ParseObject> instructionsQuery = ParseQuery.getQuery("DoggieRecipes");
//                instructionsQuery.getInBackground(DoggieRecipesList.get(position).getUserId(), new GetCallback<ParseObject>() {
//                    @Override
//                    public void done(ParseObject object, com.parse.ParseException e) {
//                        if (e == null) {
//                            // object will be your game score
//                            DoggieInstructions[0] = object.getString("instructions");
//                            txtInstructions.setText(DoggieInstructions[0]);
//
//                            Log.e("get DoggieInstructions ", " id >>>>>>>>>>>> " + DoggieInstructions[0]);
//                        } else {
//                            // something went wrong
//                            Log.e("something went wrong ", " ");
//                        }
//                    }
//
//                });
//
//
//                alertD.setView(promptView);
//
//                alertD.show();
//            }
//        });
//                view.setOnLongClickListener(new View.OnLongClickListener() {
//
//                    @Override
//                    public boolean onLongClick(View v) {
//                        ParseQuery<ParseObject> query = ParseQuery.getQuery("DoggieRecipes");
//
//// Retrieve the object by id
//                        query.getInBackground(DoggieRecipesList.get(position).getUserId(), new GetCallback<ParseObject>() {
//                            public void done(ParseObject myObject, ParseException e) {
//                                if (e == null) {
//                                    // Now let's update it with some new data. In this case, only cheatMode and score
//                                    // will get sent to the Parse Cloud. playerName hasn't changed.
//                                    myObject.remove("objectId");
//                                    myObject.remove("createdBy");
//                                    myObject.remove("title");
//                                    myObject.remove("user");
//                                    myObject.remove("ingredients");
//                                    myObject.remove("instructions");
//                                    myObject.remove("photo");
//
//                                    myObject.saveInBackground();
//                                }
//                            }
//                        });
//                            DoggieRecipesList.remove(position);
//
//                        Intent i = new Intent(context, PetFun.class);
//                        context.startActivity(i);
//
//                        return true;
//                    }
//                });


        return view;
    }



}
