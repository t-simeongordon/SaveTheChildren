package tsg.savethechildren;

import android.app.ProgressDialog;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.widget.AdapterView;
import android.widget.ListView;

import com.facebook.login.LoginManager;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

ParseUser currentUser = ParseUser.getCurrentUser();
    com.facebook.Profile profile = com.facebook.Profile.getCurrentProfile();
    // Declare Variables universal
    ProgressDialog mProgressDialog;
    ListView listview;

    // Declare Variables part 2
    List<ParseObject> di;
    EventListViewAdapter adapter;
    private List<EventFolder> EventList = null;

    private ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private String mActivityTitle;
    private ListView menuList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);

//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        /***************************** display title nav bar *************************************/

//        ActionBar actionBar = getSupportActionBar();
//        actionBar.setDisplayShowCustomEnabled(true);
//        actionBar.setDisplayShowTitleEnabled(false);
//
//        LayoutInflater inflator = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        View v = inflator.inflate(R.layout.nav_bar_title, null);
//
//        actionBar.setCustomView(v);
//
//        ColorDrawable cd = new ColorDrawable(0xff6da11f);
//        actionBar.setBackgroundDrawable(cd);

        /***************************** nav drawer *************************************/


        menuList = (ListView) findViewById(R.id.listView);
        menuList.setOnItemClickListener(new drawerOnClick());
        addDrawerItems();


        ///sets a icon in the action bar to be clicked///
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setHomeButtonEnabled(true);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.display_drawer);
        mActivityTitle = getTitle().toString();

        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
                R.string.drawer_open, R.string.drawer_close) {

            /**
             * Called when a drawer has settled in a completely open state.
             */
            public void onDrawerOpened(View drawerView) {

                super.onDrawerOpened(drawerView);
                getSupportActionBar().setTitle("Navigation!");
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }

            /**
             * Called when a drawer has settled in a completely closed state.
             */
            public void onDrawerClosed(View view) {

                super.onDrawerClosed(view);
                getSupportActionBar().setTitle(mActivityTitle);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }
        };

        new RemoteDataTask1().execute();


    }

    private void addDrawerItems() {

        menuList.setAdapter(new NavDrawerBaseAdapter(this));
    }

    private void setupDrawer() {
        mDrawerToggle.setDrawerIndicatorEnabled(true);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }
    class drawerOnClick implements AdapterView.OnItemClickListener{
        @Override public void onItemClick(AdapterView<?> parent, View view, int i, long id){

            Intent intent = null;
            switch (i) {
                case 0:
                    intent = new Intent(MainActivity.this, MainActivity.class);

                    break;

                case 1:
                    intent = new Intent(MainActivity.this, Profile.class);

                    break;
                case 2:
                    intent = new Intent(MainActivity.this, DonationMain.class);
//                    Toast.makeText(MarcTips.this,"You are already on this activity",Toast.LENGTH_LONG).show();
                    break;

                case 3:
                    intent = new Intent(MainActivity.this, CreateEvent.class);
//                    Toast.makeText(MarcTips.this,"You are already on this activity",Toast.LENGTH_LONG).show();
                    break;
                //add more if you have more items in listview
                //0 is the first item 1 second and so on...
                default: Log.e("nnnOnItemClickListener ", "not working" + menuList);
                    break;
            }
            startActivity(intent);

        }
    }


    //event feed

    // RemoteDataTask1 AsyncTask
    /*************** asyncTask 1 ***************/

    private class RemoteDataTask1 extends AsyncTask<Void, Void, Void> {
        /*************** POP UP FOR LOADING THE PARSE INFO ***************/

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Create a progressdialog
            mProgressDialog = new ProgressDialog(MainActivity.this);
            // Set progressdialog title
            mProgressDialog.setTitle("DoggieRecipes");
            // Set progressdialog message
            mProgressDialog.setMessage("Loading...");
            mProgressDialog.setIndeterminate(false);
            // Show progressdialog
            mProgressDialog.show();

        }

        @Override
        protected Void doInBackground(Void... params) {

            // Create the array
            EventList = new ArrayList<EventFolder>();

            try {
                // Locate the class table named "Country" in Parse.com
                ParseQuery<ParseObject> query = new ParseQuery<ParseObject>(
                        "Events");
                // Locate the column named "ranknum" in Parse.com and order list
                // by ascending
                query.orderByAscending("createdAt");
                query.setLimit(1000);
//                query.whereEqualTo("createdBy", ParseUser.getCurrentUser());
//                query.whereEqualTo("Public", true);

                di = query.find();
                for (ParseObject Event : di) {

//                    ParseUser k = ParseUser.getCurrentUser();
//                    ParseObject t = Event.getParseObject("createdBy");
//                    String j =t.getObjectId();

//                    Log.e("hello m "," j "+j );


//                    if(j == k.getObjectId() ||Event.getBoolean("Public") == true) {//its me or its public
                    // Locate images in photo column
                    ParseFile image = (ParseFile) Event.get("photo");
//                    ParseUser myUser = ParseUser.getCurrentUser();

                    EventFolder map = new EventFolder();
                    map.setUserId((String) Event.getObjectId());
                    map.setTitle((String) Event.get("name"));
                    map.setDescription((String) Event.get("descr"));

                    map.setPhoto(image.getUrl());
                    EventList.add(map);


                    Log.e("what happened ", "MyDogDiarylist " + EventList);

                    Log.e("what happened ", "MyDogDiarylist size" + EventList.size());
//                    }
                }
                return null;
            } catch (com.parse.ParseException e) {
                Log.e("Error", e.getMessage());

                e.printStackTrace();
            }


            return null;
        }


        @Override
        protected void onPostExecute(Void result) {


            listview = (ListView) findViewById(R.id.listview);


            // Pass the results into 0ListViewAdapter.java
            adapter = new EventListViewAdapter(MainActivity.this,
                    EventList);


            // Binds the Adapter to the ListView
            listview.setAdapter(adapter);


            // Close the progressdialog
            mProgressDialog.dismiss();



        }
    }




    private void logoutMethod() {

        if (currentUser != null && profile != null) {
            LogoutMTVforFacebookLogin();
        } else {
            LogoutMTVforEmailLogin();
        }
    }

    public void LogoutMTVforEmailLogin() {

        if (currentUser != null) {

            ParseUser.logOut();


        }
    }

    public void LogoutMTVforFacebookLogin() {
        if (currentUser != null) {
            ParseUser.logOut();
            LoginManager.getInstance().logOut();


        }
    }

    private void redirect() {
        Intent intent;
        intent = new Intent(MainActivity.this, LoginPage.class);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        switch (item.getItemId()) {

            case R.id.logout_menu:
                if (currentUser != null) {

                    logoutMethod();
                    redirect();
                } else {
                    redirect();
                }
                return true;

            case R.id.donate_menu:

                if (currentUser != null) {
Intent i = new Intent(getApplicationContext(),EventItemView.class);
                    startActivity(i);

                } else {


                }
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
