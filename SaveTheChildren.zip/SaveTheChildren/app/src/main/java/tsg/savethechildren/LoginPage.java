package tsg.savethechildren;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;

/**
 * Created by terrelsimeongordon on 15/09/15.
 */
public class LoginPage extends AppCompatActivity {

    private FragmentManager mFragmentManager;
    RelativeLayout fb_frag_placement;
    public static final String FRAGMENT_TAG = "fragment_tag";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page_activity);

/***************************** run facebook *************************************/
        mFragmentManager = getSupportFragmentManager();

        fb_frag_placement = (RelativeLayout)findViewById(R.id.fb_frag_placement);

        sendFBrequest();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    private void sendFBrequest(){

        Fragment fragment = mFragmentManager.findFragmentByTag(FRAGMENT_TAG);
        FragmentTransaction transaction = mFragmentManager.beginTransaction();

        transaction.replace(R.id.fb_frag_placement, new FragmentCustomLoginButton(), FRAGMENT_TAG);

        transaction.commit();

    }


    public void loginOnClick(View v) {
        Intent intent;

        intent = new Intent(LoginPage.this, MainActivity.class);
        if (v.getId() == R.id.login_skip) {
            startActivity(intent);
        }intent = new Intent(LoginPage.this, LoginRegisterEmail.class);
        if (v.getId() == R.id.login_register_email) {
            startActivity(intent);
        }intent = new Intent(LoginPage.this, LoginEmail.class);
        if (v.getId() == R.id.login_email) {
            startActivity(intent);
        }
    }
//    @Override
//    protected void onPause() {
//        super.onPause();
//        finish();
//        Intent i = new Intent (this, MTV_SplashPage.class);
//        startActivity(i);
//    }

}