package tsg.savethechildren;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.util.Date;


/**
 * Created by terrelsimeongordon on 18/09/15.
 */
public class CreateEvent extends AppCompatActivity{
    private ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private String mActivityTitle;
    private ListView menuList;

        String submitUser=null;
        String submitIngredients=null;
        String submitInstructions=null;

    ImageView buttonLoadImage;
        ParseFile file;


        static final String stringPath = "FILE PATH" ;
        static final int REQUEST_IMAGE_CAPTURE = 1;
        static final int RESULT_LOAD_IMAGE = 2;

        String picturePath;

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            // Get the view from 0listview_main.xml
            setContentView(R.layout.doggie_recipes_form_activity);


//        Resources res = getResources();
//        Drawable drawable = res.getDrawable(R.drawable.temp_img);
//        Bitmap bitmap = ((BitmapDrawable)drawable).getBitmap();
//        ByteArrayOutputStream stream = new ByteArrayOutputStream();
//        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
//        byte[] bitMapData = stream.toByteArray();
//        file = new ParseFile("pic.png", bitMapData);
//
//       Log.e("what happened ","picture "+bitMapData);
            buttonLoadImage=(ImageView)findViewById(R.id.gallery_photo);

            buttonLoadImage.setOnClickListener(new View.OnClickListener() {


                @Override
                public void onClick(View arg0) {


                    Intent i = new Intent(
                            Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                    startActivityForResult(i, RESULT_LOAD_IMAGE);


                }
            });

//            /***************************** display title nav bar *************************************/
//
//            ActionBar actionBar = getSupportActionBar();
//            actionBar.setDisplayShowCustomEnabled(true);
//            actionBar.setDisplayShowTitleEnabled(false);
//
//            LayoutInflater inflator = (LayoutInflater) this .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//            View v = inflator.inflate(R.layout.nav_bar_title, null);
//
//            actionBar.setCustomView(v);
//
//            ColorDrawable cd = new ColorDrawable(0xff6da11f);
//            actionBar.setBackgroundDrawable(cd);

            /***************************** nav drawer *************************************/


            menuList = (ListView) findViewById(R.id.listView);
            menuList.setOnItemClickListener(new drawerOnClick());
            addDrawerItems();


            ///sets a icon in the action bar to be clicked///
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setHomeButtonEnabled(true);

            mDrawerLayout = (DrawerLayout) findViewById(R.id.display_drawer);
            mActivityTitle = getTitle().toString();

            mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
                    R.string.drawer_open, R.string.drawer_close) {

                /**
                 * Called when a drawer has settled in a completely open state.
                 */
                public void onDrawerOpened(View drawerView) {

                    super.onDrawerOpened(drawerView);
                    getSupportActionBar().setTitle("Navigation!");
                    invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
                }

                /**
                 * Called when a drawer has settled in a completely closed state.
                 */
                public void onDrawerClosed(View view) {

                    super.onDrawerClosed(view);
                    getSupportActionBar().setTitle(mActivityTitle);
                    invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
                }
            };

        }


    private void addDrawerItems() {

        menuList.setAdapter(new NavDrawerBaseAdapter(this));
    }

    private void setupDrawer() {
        mDrawerToggle.setDrawerIndicatorEnabled(true);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }
    class drawerOnClick implements AdapterView.OnItemClickListener{
        @Override public void onItemClick(AdapterView<?> parent, View view, int i, long id){

            Intent intent = null;
            switch (i) {
                case 0:
                    intent = new Intent(CreateEvent.this, MainActivity.class);

                    break;

                case 1:
                    intent = new Intent(CreateEvent.this, Profile.class);

                    break;
                case 2:
                    intent = new Intent(CreateEvent.this, DonationMain.class);
//                    Toast.makeText(MarcTips.this,"You are already on this activity",Toast.LENGTH_LONG).show();
                    break;

                case 3:
                    intent = new Intent(CreateEvent.this, CreateEvent.class);
//                    Toast.makeText(MarcTips.this,"You are already on this activity",Toast.LENGTH_LONG).show();
                    break;
                //add more if you have more items in listview
                //0 is the first item 1 second and so on...
                default: Log.e("nnnOnItemClickListener ", "not working" + menuList);
                    break;
            }
            startActivity(intent);

        }
    }



    public void launchCamera(View view){
            Intent intent = new Intent (MediaStore.ACTION_IMAGE_CAPTURE);
            //Take pictures and pass results along to onActivityResults
            startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
        }


//If you want to return the image taken

        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
            //  Log.e(null,"i am here");

            if (
                    requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
                //GET PHOTO
                Bundle extras = data.getExtras();
                Bitmap photo = (Bitmap) extras.get("data");
//            photo = bitmapResize(photo);
//            photoImageView.setImageBitmap(photo);
                Log.e("my image ", " captured version " + photo);

//            saveToInternalStorage(photo);

                // launchActivity();

                checkImageVersion(photo);


            } else if
                    (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
                Uri selectedImage = data.getData();
                String[] filePathColumn = {MediaStore.Images.Media.DATA};

                Cursor cursor = getContentResolver().query(selectedImage,
                        filePathColumn, null, null, null);
                cursor.moveToFirst();

                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                picturePath = cursor.getString(columnIndex);

                cursor.close();

                Bitmap uploadPhoto =  BitmapFactory.decodeFile(picturePath);
                Log.e("my image ", " main error response : " + picturePath);
                Log.e("my image ", " loaded version " + uploadPhoto);
                checkImageVersion(uploadPhoto);
            }


        }

        private void checkImageVersion( Bitmap parsePhoto){
            if( parsePhoto!=null){

                makeParsePhoto(parsePhoto);

            }else {
                Log.e("my image ", " loaded version check" + parsePhoto);
            }
        }

        private void makeParsePhoto(Bitmap parsePhoto){
            Bitmap Offer1BitmapResized = Bitmap.createScaledBitmap(parsePhoto, 900, 1600, true);

            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            Offer1BitmapResized.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            byte[] bitMapData = stream.toByteArray();
            file = new ParseFile("pic.png", bitMapData);
        }

        public void recipeForm(View v){

            validSubmission();
        }

        private void validSubmission() {



            EditText processIngredients = (EditText) findViewById(R.id.rec_ingredients_edittext);
            submitIngredients = processIngredients.getText().toString();

            EditText processInstructions = (EditText) findViewById(R.id.rec_instructions_edittext);
            submitInstructions = processInstructions.getText().toString();

            if (!submitIngredients.contentEquals("") &&
                    !submitInstructions.contentEquals("") ) {

                sendRecipeToParse();

            }
        }

        private void sendRecipeToParse(){
            ParseObject gameScore = new ParseObject("Events");
            gameScore.put("author", ParseUser.getCurrentUser());
            gameScore.put("name", submitIngredients);
            gameScore.put("description", submitInstructions);
            gameScore.put("photo", file);
            gameScore.saveInBackground();


            Intent intent;
//
                                intent = new Intent(getApplicationContext(), MainActivity.class);
                                startActivity(intent);

        }


    }
