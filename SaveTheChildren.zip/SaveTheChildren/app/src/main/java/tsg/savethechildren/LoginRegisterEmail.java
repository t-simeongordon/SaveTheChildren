package tsg.savethechildren;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import com.parse.Parse;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SaveCallback;
import com.parse.SignUpCallback;

import java.util.Date;

/**
 * Created by terrelsimeongordon on 15/09/15.
 */
public class LoginRegisterEmail extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    Context context = this;

    boolean correctEmail, correctPassword;
    String over18;
    int EmailRegisterPoints = 1000;
    final ParseUser user = new ParseUser();
    int startingNumber = 0;
Switch over18Switch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_register_email_activity);
        over18Switch= (Switch)findViewById(R.id.over18Switch);
        over18Switch.setOnCheckedChangeListener(this);
        //   Log.e("text saved ", ">>>>>>>>>>>>"+text);

    }

    public void sendData(View v) {

        EditText registerUserName = (EditText) findViewById(R.id.register_user_name_input);
        EditText registerEmail = (EditText) findViewById(R.id.register_email_input);
        EditText registerConfirm_MarketEmail = (EditText) findViewById(R.id.register_confirm_email_input);
        EditText registerPassword = (EditText) findViewById(R.id.register_password_input);
        EditText registerConfirmPassword = (EditText) findViewById(R.id.register_confirm_password_input);

        String name = registerUserName.getText().toString();
        String email = registerEmail.getText().toString();
        String confirm_MarketEmail = registerConfirm_MarketEmail.getText().toString();
        String password = registerPassword.getText().toString();
        String confirmPassword = registerConfirmPassword.getText().toString();

        if (email.equals(confirm_MarketEmail)) {
            correctEmail = true;
        } else {
            correctEmail = false;

        }

        if (password.equals(confirmPassword)) {
            correctPassword = true;

        } else {
            correctPassword = false;

        }


        if (correctEmail == true) {

            if (correctPassword == true) {
                ParseUser currentUser = ParseUser.getCurrentUser();
                if (currentUser != null) {
                    ParseUser.logOut();

                    // do stuff with the user
                } else {
                    // show the signup or login screen
                }

                user.setUsername(registerEmail.getText().toString());
                user.setPassword(registerPassword.getText().toString());
                user.setEmail(registerConfirm_MarketEmail.getText().toString());
// other fields can be set just like with ParseObject
                user.put("name", registerUserName.getText().toString());
                user.put("LoginType", "Email");
                user.put("areyou18", over18);
                Log.e("text saved ", "???????????1 " + name);
                Log.e("text saved ", "???????????2 " + email);
                Log.e("text saved ", "???????????3 " + confirm_MarketEmail);
                Log.e("text saved ", "???????????4 " + password);

                user.signUpInBackground(new SignUpCallback() {
                    public void done(ParseException e) {
                        if (e == null) {


//                            user.saveInBackground();

                            // Hooray! Let them use the app now.


                         Intent   intent = new Intent(LoginRegisterEmail.this, MainActivity.class);
                            startActivity(intent);

                        } else {
                            Toast.makeText(getApplicationContext(), "error please try again" + e.toString(),
                                    Toast.LENGTH_LONG).show();

                            // Sign up didn't succeed. Look at the ParseException
                            // to figure out what went wrong
                        }
                    }
                });
            } else {
                Toast.makeText(getApplicationContext(), "Wrong password please try again",
                        Toast.LENGTH_LONG).show();

            }
        } else {
            Toast.makeText(getApplicationContext(), "Wrong Email please try again",
                    Toast.LENGTH_LONG).show();
        }

    }

    public void loginBkOnClick(View v) {
        Intent intent;

        intent = new Intent(LoginRegisterEmail.this, LoginPage.class);
        startActivity(intent);

    }

    @Override
    /// checks to see the switch
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            // do something when check is selected
            over18 = "Yes";
        } else {
            //do something when unchecked
            over18 = "No";
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
