package tsg.savethechildren;

import android.view.View;
        import android.widget.ImageButton;
        import android.widget.ImageView;
        import android.widget.TextView;


public class NavDrawerViewHolder {

    ImageView image ;
    TextView title;
    //this is how you pass in the values from your context

    NavDrawerViewHolder(View V)
    {
        image = (ImageView) V.findViewById(R.id.video);
        title =(TextView) V.findViewById(R.id.textView);
    }




}
