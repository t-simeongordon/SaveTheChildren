package tsg.savethechildren;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.facebook.Profile;
import com.parse.ParseUser;

/**
 * Created by terrelsimeongordon on 15/09/15.
 */
public class MTV_SplashPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_mtv);
        Thread timer = new Thread() {

            public void run() {

                try {

                    synchronized(this){
                        wait(3000);
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    if (ParseUser.getCurrentUser() != null || Profile.getCurrentProfile() != null) {
                        Intent openString = new Intent(MTV_SplashPage.this, MainActivity.class);
                        startActivity(openString);
                        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                    }else {
                        Intent openString = new Intent(MTV_SplashPage.this, LoginPage.class);
                        startActivity(openString);
                        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                    }
                }
            }

        };
        timer.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

}
