package tsg.savethechildren;

/**
 * Created by terrelsimeongordon on 13/10/15.
 */
import android.util.Log;

public class EventFolder {
    private String title;
    private String description;
    private String photo;
    private String userId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        Log.e("what happened ","get description instance1 "+ description);

        return description;
    }

    public void setDescription(String description) {
        Log.e("what happened ","set description instance2 "+description);

        this.description = description;
    }


    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
