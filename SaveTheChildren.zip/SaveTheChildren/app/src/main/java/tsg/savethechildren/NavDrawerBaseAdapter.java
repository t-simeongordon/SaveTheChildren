package tsg.savethechildren;

import android.content.Context;
import android.content.res.Resources;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;

/**
 * Created by terrelsimeongordon on 29/09/15.
 */
class NavDrawerBaseAdapter extends BaseAdapter {
    NavDrawerViewHolder holder = null;

    String[] videoTitle;
    String[] videoDescription;
    int[] images;

    ArrayList<NavDrawerSingleRow> list;
    //kind of makes a class id
    Context context;

    NavDrawerBaseAdapter(Context c) {
        list = new ArrayList<NavDrawerSingleRow>();
        context = c;
        Resources res = c.getResources();
        videoTitle = res.getStringArray(R.array.titles);
        images = new int[]{R.drawable.home_img, R.drawable.profile_img , R.drawable.donation_img,
                R.drawable.event_img};

        for (int n = 0; n < 4; n++) {

            Log.e("lara ity list size", "  " + list.size());
            Log.e("lara ity list 1 ", "  " + n);

            list.add(new NavDrawerSingleRow(videoTitle[n], images[n]));



        }


    }
    //overide the base adapter
    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {


//        n++;
//        m++;
        return i;
    }

    @Override
    public final boolean hasStableIds() {
        return true;
    }

    @Override
    public View getView(final int i, View convertView, ViewGroup viewGroup) {
        View row = convertView;


        if (row == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.navergation_adapter_layout, viewGroup, false);
            holder = new NavDrawerViewHolder(row);
            row.setTag(holder);

            Log.d("my holder", " creating a new row ");

        } else {
            holder = (NavDrawerViewHolder) row.getTag();
            Log.d("my holder", " recycling in process ");
        }


        NavDrawerSingleRow temp = list.get(i);

        holder.title.setText(temp.title);
        holder.image.setImageResource(temp.images);
        return row;
    }


}
