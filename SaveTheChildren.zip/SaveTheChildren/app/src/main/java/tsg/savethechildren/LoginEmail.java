package tsg.savethechildren;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.RequestPasswordResetCallback;

/**
 * Created by terrelsimeongordon on 16/09/15.
 */
public class LoginEmail extends AppCompatActivity {
    String sentEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_email_activity);

    }

   public void runMtv(View v){

       EditText mainEmail = (EditText) findViewById(R.id.email_input);
       EditText mainPassword = (EditText) findViewById(R.id.password_input);

       String profileName = mainEmail.getText().toString();
       String profileEmail = mainPassword.getText().toString();

       ParseUser currentUser = ParseUser.getCurrentUser();
           if (currentUser != null) {
           ParseUser.logOut();

           // do stuff with the user
       } else {
           // show the signup or login screen
       }

       ParseUser.logInInBackground(profileName, profileEmail, new LogInCallback() {
           public void done(ParseUser user, ParseException e) {
               if (user != null) {
                   Intent intent;

                   intent = new Intent(LoginEmail.this, MainActivity.class);

                   startActivity(intent);

                   Toast.makeText(getApplicationContext(), "Welcome ",
                           Toast.LENGTH_LONG).show();
                   // Hooray! The user is logged in.
               } else {
                   Toast.makeText(getApplicationContext(), "error wrong account" + e.toString(),
                           Toast.LENGTH_LONG).show();

                   // Signup failed. Look at the ParseException to see what happened.
               }
           }
       });
    }

    public void forgotPasswordDialog(View v) {

        final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setTitle("Email Address");
        LayoutInflater inflater = this.getLayoutInflater();
        View view = inflater.inflate(R.layout.login_forgot_password, null);
        dialogBuilder.setView(view);
        final EditText change_password_input = (EditText) view.findViewById(R.id.change_password_input);

        dialogBuilder.setPositiveButton("change password", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                sentEmail = change_password_input.getText().toString();

                ParseUser.requestPasswordResetInBackground(sentEmail, new RequestPasswordResetCallback() {
                    public void done(ParseException e) {
                        if (e == null) {
                            Toast.makeText(getApplicationContext(), "an email has been set to this account\n" +
                                                                    "follow as instructed to rest your email",
                                    Toast.LENGTH_LONG).show();
                            // An email was successfully sent with reset instructions.
                        } else {
                            Toast.makeText(getApplicationContext(), "Invalid Email: "+sentEmail+" does not exist\n" +
                                                                    "please try again",
                                    Toast.LENGTH_LONG).show();

                            Log.e("why you no work ", " " + e.toString());
                            // Something went wrong. Look at the ParseException to see what's up.
                        }
                    }
                });
                dialog.dismiss();
            }
        });


            dialogBuilder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    dialog.dismiss();
                }
            });
        AlertDialog calendarAlert = dialogBuilder.create();
        calendarAlert.show();

    }

}
